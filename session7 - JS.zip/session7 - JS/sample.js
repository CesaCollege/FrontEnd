const child = document.querySelector('.child')
const parent = document.querySelector('.parent')
const grandparent = document.querySelector('.grandparent')

// grandparent.addEventListener('click', e=> console.log('parent'), {capture:true})
// parent.addEventListener('click', e=> {
//     console.log('grandparent')
// }, {capture:true})
// child.addEventListener('click', e=> console.log('child'), {capture:true})


// grandparent.addEventListener('click', e=> console.log('grandparent') )
// child.addEventListener('click', e=> console.log('child'), {once:true} )
// parent.addEventListener('click', e=> console.log('parent'))

parent.addEventListener("click",
    e => {
        e.stopPropagation()
    console.log("Parent Capture")
    },
    { capture: true })
parent.addEventListener("click", e => {
    console.log("Parent Bubble")
})

child.addEventListener("click",
    e => {
    console.log("Child Capture")
    },
    { capture: true })
child.addEventListener("click", e => {
    console.log("Child Bubble")
    })

document.addEventListener(
    "click",
    e => {
    console.log("Document Capture")
    },
    { capture: true }
)
document.addEventListener("click",e=>
    console.log("Document Bubble"))