//DOM Manipulation:
// https://www.scaler.com/topics/javascript-dom-manipulation/
// Document is the core/foundation of the DOM.
// HTML root element is the child of the document object.
// Body and Head elements are the children of the HTML element and siblings to each other.
// Title element is the parent to the text node: "my text” and the child of the head element.
// a tag and h1 tag are the children of the body element and siblings to each other.
// href attribute is the children of the a(anchor) tag.
// The DOM is referred to as a programming API for XML and HTML documents. 
// DOM defines the logical structure of documents and the methods for accessing and changing them are specified by the DOM.

// Few Points to Keep in Mind:
// A node can have more than one child.
// Siblings are nodes with the same parent like brothers or sisters.
// Except for the top node, which has no parent, each node has exactly one parent.


// How to Select Elements in the DOM
// In order to change or modify an element in the DOM, you need to select that specific element. 
// Thus, JavaScript has six methods to select an element from a document in dom manipulation in javascript.

// getElementById: returns an element whose id matches a passed string. 
// Since the ids of elements are unique, this is the fastest way to select an element.

// getElementsByTagName: returns a collection of all the elements present in the document that have the specified tag name, 
// in the order of their appearance in the document.

// getElementsByClassName: returns an HTMLCollection of elements that match the passed class name. 
// Bypassing the class names separated by whitespace, we can search for multiple class names.

// getElementsByName: returns a NodeList Collection of the elements that match the value of the name attribute with the passed string.

// querySelector: returns the very first element within the document that matches the given selector.
// It only returns the element that matches with one of the specified CSS selectors, or a group of selectors.

// querySelectorAll: returns a static NodeList of elements that matches with one or a group of selectors. 
// If no element matches, an empty NodeList is returned.

// Get Child Elements
// To Get all child elements use the firstChild property that returns the first child element of a specified element.
// let firstChild = parentElement.firstChild; 

// To Get the last child element use the lastChild property that returns the first element node, 
// text node, or comment node.
// let lastChild = parentElement.lastChild; 

// To Get all child elements use the childNodes property that returns a live NodeList of child elements of a specified element.
// let children = parentElement.childNodes;

// Get Siblings of an Element
// To Get the next siblings use the nextElementSibling property

// let nextSibling = currentNode.nextElementSibling;
// To Get the previous siblings use the previousElementSibling property.

// let current = document.querySelector('.current');
// let prevSibling = currentNode.previousElementSibling; 


//How to Manipulate Elements in the DOM:
// Create a New Element
// The document.createElement() returns a new Node with the Element type. It takes an HTML tag name as a parameter.
let div = document.createElement('div');

// Get and Set the Text Content of a Node
// The textContent property returns the concatenation of the textContent of all child nodes and does not include the comments.
let text = node.textContent;

// Get and Set the HTML Content of an Element
// The innerHTML is a property of the Element that allows us to get or set the HTML markup contained within the element.
element.innerHTML = 'new content';

// Append a Node to a List of Child Nodes of a Particular Parent Node
// The appendChild() method allows us to insert a node at the end of the list of child nodes of a particular parent node.
parentNode.appendChild(childNode);

// Insert One Element Before an Existing Node as a Child Node of a Specified Parent Node
// The insertBefore() JavaScript method takes two parameters, the newNode, and the existingNode. 
// insertBefore() returns the inserted child node.
parentNode.insertBefore(newNode, existingNode);

// Replace a Child Element by a New Element
// The replaceChild() JavaScript method takes two parameters to replace our first element with the newly created one.
parentNode.replaceChild(newChild, oldChild);

// Remove Child Elements of a Node
// The removeChild() JavaScript method takes just one parameter i.e the element you want to remove.
let childNode = parentNode.removeChild(childNode);

// Clone an Element and All of Its Descendants
// This method allows us to clone an element. The cloneNode() method takes a parameter deep that is optional. 
// If the deep is true, then the original node and all of its descendants are already cloned, false otherwise.
let clonedNode = originalNode.cloneNode(deep);

// style property
// The style property returns the read-only CSSStyleDeclaration object that includes a list of CSS properties.
element.style.color = 'red';




//Event Listeners: addEventListener()
// An event is an important part of JavaScript.A web page responds according to an event that occurred. 
// Some events are user generated and some are generated by API. An event listener is a procedure in JavaScript that waits for 
// an event to occur. A simple example of an event is a user clicking the mouse or pressing a key on the keyboard.
// The addEventListener() is an inbuilt function in JavaScript which takes the event to listen for, 
// and a second argument to be called whenever the described event gets fired. 
// Any number of event handlers can be added to a single element without overwriting existing event handlers. 
//the specified event is delivered to the target.
//Common targets are Element, or its children, Document, and Window.
//It allows adding more than one handler for an event.
//The method addEventListener() works by adding a function, or an object that implements EventListener, 
//to the list of event listeners for the specified event type on the EventTarget on which it's called. 
//If the function or object is already in the list of event listeners for this target, the function or object is not added a second time.
element.addEventListener(event, listener, useCapture);
// Parameters:  
// event: event can be any valid JavaScript event. Events are used without “on” prefixes 
// like using “click” instead of “onclick” or “mousedown” instead of “onmousedown”.
// listener(handler function) : It can be a JavaScript function that respond to the event occurring.
// useCapture: It is an optional parameter used to control event propagation. 
// A boolean value is passed where “true” denotes capturing phase and “false” denotes the bubbling phase.

<body>
    <div class="first">
        <p>one</p>
        <p>Two</p>
    </div>
    <button id="try">Click here</button>
    <h1 id="text"></h1>
    <script>
    document.getElementById("try").addEventListener("click", function(){
    document.getElementById("text").innerText = "Cesa College";
});
    </script>
</body>

//list of javascript events: https://developer.mozilla.org/en-US/docs/Web/Events

// Exercise:
// add and alert when checkbox is clicked:
{/* <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JavaScript Checkbox</title>
</head>

<body>
    <label for="accept">
        <input type="checkbox" id="accept" name="accept"> Accept
    </label>

    <button id="btn">Submit</button>

    <script>
    </script>
</body> */}


