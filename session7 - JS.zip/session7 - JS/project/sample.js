const songs = [
    "No time to die",
    "Save your tears",
    "the hills"
]

const total = document.querySelector('.total');
const songList = document.querySelector('.mix')
const button = document.querySelector('.show-list')

total.innerHTML = `${songs.length} songs of all time!`

button.addEventListener("click", function(){
    mixSongs(songs);
    songList.classList.remove('hide')
    button.classList.add('hide')
});

const mixSongs = function(mix){
    mix.forEach(function(song, index){
        let li = document.createElement("li")
        li.classList.add('song');
        li.innerHTML = `#${index + 1} ${song}`;
        songList.append(li);
    });
}




