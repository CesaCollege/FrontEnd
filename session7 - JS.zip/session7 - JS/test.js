const grandparent = document.querySelector(".grandparent");
const parent = document.querySelector(".parent");
const child = document.querySelector(".child");
// console.log(child)

// grandparent.addEventListener('click', e => {
//     console.log('1')
// })
// grandparent.addEventListener('click', e => {
//     console.log('2')
// })

//bubbling
// grandparent.addEventListener("click", e => {
//     console.log("Grandparent 1")
// })
// parent.addEventListener("click", e => {
//     console.log("Parent 1")
// })
// child.addEventListener("click", e => {
//     console.log("Child 1")
// })
// document.addEventListener("click", e => {
//     console.log("Document 1")
// })

//capturing
// grandparent.addEventListener("click", e => {
//     console.log("Grandparent 1")
//     }, { capture: true })
//     parent.addEventListener("click", e => {
//     console.log("Parent 1")
//     })
//     child.addEventListener("click", e => {
//     console.log("Child 1")
//     })
//     document.addEventListener("click", e => {
//     console.log("Document 1")
//     })

//contrasting capture and bubbling and propogration
// parent.addEventListener("click",
//     e => {
//         //e.stopPropagation()
//     console.log("Parent Capture")
//     },
//     { capture: true })
// parent.addEventListener("click", e => {
//     console.log("Parent Bubble")
// })

// child.addEventListener("click",
//     e => {
//     console.log("Child Capture")
//     },
//     { capture: true })
// child.addEventListener("click", e => {
//     console.log("Child Bubble")
//     })

// document.addEventListener(
//     "click",
//     e => {
//     console.log("Document Capture")
//     },
//     { capture: true }
// )
// document.addEventListener("click",e=>
//     console.log("Document Bubble"))

//once:
// grandparent.addEventListener("click", (e) => {
//   console.log("Grandparent 1");
// });
// parent.addEventListener(
//   "click",
//   (e) => {
//     console.log("Parent 1");
//   },
//   { once: true }
// );
// child.addEventListener("click", (e) => {
//   console.log("Child 1");
// });



//after three times:
// grandparent.addEventListener("click", (e) => {
//   console.log("Grandparent Bubble");
// });

// parent.addEventListener("click", printHi);
// setTimeout(() => {
//   parent.removeEventListener("click", printHi);
// }, 2000);

// child.addEventListener("click", (e) => {
//   console.log("Child Bubble");
// });

// function printHi() {
//   console.log("Hi");
// }


//delegations:
// const divs = document.querySelectorAll("div")
// document.addEventListener("click", e => {
// if (e.target.matches("div")) {
// console.log("hi")}
// })
// const newDiv = document.createElement("div")
// newDiv.style.width = "200px"
// newDiv.style.height = "200px"
// newDiv.style.backgroundColor = "purple"
// document.body.append(newDiv)