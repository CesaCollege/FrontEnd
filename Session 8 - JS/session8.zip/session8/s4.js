//explain object and diff types
// object with properties & method
//Note that the whole key-value pair must be declared. Declaring only a key without a value is invalid, as shown below.
var person = {
  firstName: "James",
  lastName: "Bond",
  age: 15,
  getFullName: function () {
    return this.firstName + " " + this.lastName;
  },
};
//another way
var person = new Object();
// Attach properties and methods to person object
person.firstName = "James";
person["lastName"] = "Bond";
person.age = 25;
person.getFullName = function () {
  return this.firstName + " " + this.lastName;
};
person.getFullName();
// access properties & methods
document.getElementById("p1").innerHTML = person.firstName;
document.getElementById("p2").innerHTML = person.lastName;

//nested:
var person = {
    firstName: "James",
    lastName: "Bond",
    age: 25,
    address: {
        id: 1,
        country:"UK"
    }
  };
  person.address.country; // returns "UK"
  
  //pass by reference:
  // In Pass by Reference, a function is called by directly passing the reference/address of the variable as the argument. 
  // Changing the argument inside the function affects the variable passed from outside the function.
  //  In Javascript objects and arrays are passed by reference.
  function changeFirstName(per)
  {
    per.firstName = "Steve";
  }
  changeFirstName(person)    
  console.log(person.firstName); 
  
  
  //Date()
  //new Date(year, monthIndex, day, hours, minutes, seconds, milliseconds)
  //No Parameters: A date object will be set to the current date & time if no parameter is specified in the constructor.
  //https://www.tutorialsteacher.com/javascript/javascript-date-methods-reference
  
  //OOP:
  //We'll describe three main concepts: classes and instances, inheritance, and encapsulation.
  //Object-oriented programming is about modeling a system as a collection of objects, 
  //where each object represents some particular aspect of the system. Objects contain both functions (or methods) and data.


//map:
let arr = [3, 4, 5, 6];
// Task: multiply each number of the array by 3.
//let students do it with for
let modifiedArr = arr.map(function (element) {
  return element * 3;
});
// let modifiedArr = arr.map( element => element *3);

console.log(arr);
console.log(modifiedArr);

let users = [
  { firstName: "Susan", lastName: "Steward" },
  { firstName: "Daniel", lastName: "Longbottom" },
  { firstName: "Jacob", lastName: "Black" },
];

let userFullnames = users.map(function (element) {
  return `${element.firstName} ${element.lastName}`;
});

console.log(userFullnames);


//full syntax:

arr.map(function(element, index, array){
    console.log(element);
    console.log(index);
    console.log(array);
    return element;
}, 80);

//undefined
//ask question
arr.map(function(element, index, array){
    console.log(array[index + 1]);
});


//this in map
arr.map(function(element, index, array){
    console.log(element);
    console.log(index);
    console.log(array);
    console.log(this);
}, 80);

//explain this concept:
//JavaScript “this” keyword. 
// “This” keyword refers to an object that is executing the current piece of code. 
// It references the object that is executing the current function. 
// If the function being referenced is a regular function,
//  “this” references the global object.
// method -> obj
// function ->global (window in browser, global in node)
const video = {
    title: 'a',
play() {
    console.log(this);
}
};
video.play();

//global example:
function playVideo () {
    console.log(this);
}
playVideo();



//filter method
//filter(callbackFn, thisArg)
const words = ['spray', 'limit', 'elite', 'exuberant', 'destruction', 'present'];
const result = words.filter((word) => word.length > 6);
console.log(result);
// Expected output: Array ["exuberant", "destruction", "present"]


//Filter array items based on search criteria (query):
function filterItems(arr, query) {
 return arr.filter((el) => el.toLowerCase().includes(query.toLowerCase()));
}

console.log(filterItems(fruits, "ap")); // ['apple', 'grapes']
console.log(filterItems(fruits, "an")); // ['banana', 'mango', 'orange']


let users1 = [
    { name: 'John', age: 25, occupation: 'gardener' },
    { name: 'Lenny', age: 51, occupation: 'programmer' },
    { name: 'Andrew', age: 43, occupation: 'teacher' },
    { name: 'Peter', age: 81, occupation: 'teacher' },
    { name: 'Anna', age: 47, occupation: 'programmer' },
    { name: 'Albert', age: 76, occupation: 'programmer' },
]
let filteredUsers = users.filter(user => user.age > 40 && user.occupation === 'programmer');
console.log(filteredUsers);

//example for students to solve:
let filteredUserNames = users.filter(user => user.age > 40 && user.occupation === 'programmer')
    .sort((a, b) => a.age - b.age)
    .map(user => user.name);

console.log(filteredUserNames); // ['Anna', 'Lenny', 'Albert']

//filter for objects
const userDetails = {
    firstName: "Jane",
    lastName: "Daniels",
    userName: "jane.daniels",
    email: "jane.daniels@example.com",
    comapny: "Example Inc.",
    address: "1234 Example Street",
    age : 25,
    hobby: "Singing"
};

let keysArray = Object.keys(userDetails);
console.log(keysArray);


//In summary, forEach is used for performing actions on each element of an array, 
// filter is used for creating a new array with elements that satisfy a specific condition, 
// and map is used for creating a new array by transforming each element in the original array.
//example:
const numbers = [1, 2, 3, 4, 5];

// forEach example
console.log("forEach:");
numbers.forEach(function(number) {
  console.log(number * 2);
});
console.log(numbers)

// filter example
console.log("filter:");
const filteredNumbers = numbers.filter(function(number) {
  return number % 2 === 0;
});
console.log(filteredNumbers);
// Output: [2, 4]

// map example
console.log("map:");
const doubledNumbers = numbers.map(function(number) {
  return number * 2;
});
console.log(doubledNumbers);
// Output: [2, 4, 6, 8, 10]


//JSON
// JSON stands for JavaScript Object Notation
// JSON is a lightweight format for storing and transporting data
// JSON is often used when data is sent from a server to a web page
// JSON is "self-describing" and easy to understand
// Data is in name/value pairs
// Data is separated by commas
// Curly braces hold objects
// Square brackets hold arrays
//show exmaple: