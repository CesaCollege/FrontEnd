const songs = [
    { name: "No time to die", genre:"classic"},
    { name: "Save your tears", genre:"pop"},
    { name: "the hills", genre:"pop"}, 
]

const total = document.querySelector('.total');
const songList = document.querySelector('.mix')
const button = document.querySelector('.show-list')
const hidebtn = document.querySelector('.hide-list')
let funcCalled = false;
total.innerHTML = `${songs.length} songs of all time!`


button.addEventListener("click", function(){
    if(!funcCalled){
        mixSongs(songs);
        funcCalled = true
    }
    songList.classList.remove('hide')
    button.classList.add('hide')
    hidebtn.classList.remove('hide');
});

hidebtn.addEventListener("click", function(){
    songList.classList.add('hide')
    button.classList.remove('hide')
    hidebtn.classList.add('hide');

});

//give homework
const mixSongs = function(mix) {
    const popSongs = mix.filter((song) => song.genre === "pop");
  
    popSongs.forEach(function(song, index) {
      let li = document.createElement("li");
      li.classList.add("song");
      li.innerHTML = `#${index + 1} name:${song.name}, genre:${song.genre}`;
      songList.append(li);
    });
  };






