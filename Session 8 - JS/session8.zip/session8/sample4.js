const numbers = [1,4,19]

console.log("Foreach:")
const nums = numbers.forEach((number)=>number*2)
console.log(nums)

console.log("Filter:")
const filtered = numbers.filter((number)=>number%2===0)
console.log(filtered)

console.log("Map:")
const mapped = numbers.map((number)=>number*2)
console.log(mapped)